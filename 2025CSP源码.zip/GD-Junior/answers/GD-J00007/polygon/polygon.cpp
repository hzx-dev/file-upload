#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("polygon.in","r",stdin);
	freopen("polygon.out","w",stdout);
	int n;
	int a[5001];
	cin >> n;
	for(int i = 1;i <= n;i++)
	{
		cin >> a[i];
	}
	cout << 9;
	return 0;
}
