#include<bits/stdc++.h>
using namespace std;
string a;
long long aa[1000005],ii=0,aaa;
int main(){
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	cin >> aaa;
	cout << aaa;
	return 0;
} 
