#include<iostream>
#include<bits/stdc++.h>
using namespace std;
int main(){
    freopen("xor.in","r",stdin);
    freopen("xor.out","w",stdout);
    long long l[1000005],k,n;
    cin>>n>>k;
    for(int i=1;i<=n;i++){
        cin>>l[i];
    }
    cout<<k;
    fclose(stdin);
    fclose(stdout);
    return 0;
}

