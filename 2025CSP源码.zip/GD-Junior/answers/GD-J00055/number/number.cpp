#include<bits/stdc++.h>
using namespace std;
string s,num;
long long a[10];
int main()
{
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	cin>>s;
	for(int i=0;i<s.size();i++)
	{
		if(s[i]>='0'&&s[i]<='9')
		{
			a[(s[i]-'0')]++;
		}
	}
	num="";
	for(int i=9;i>=0;i--)
	{
		while(a[i]!=0)
		{
			num+=(i+'0');
			a[i]--;
		}
	}
	cout<<num;
	return 0;
} 
