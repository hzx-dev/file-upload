#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jijiawfadaudadyaudgaud=
	else if;
	cin>>
	cout<<92100;
	return 0;#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];rwrwwr839ru 
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);

	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){h�����ۺͷ�������for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){u
	sort(signed main(){jiji
	else if;
	cin>>
	cout<<92100;
	return 0;
}#include<bits/stdc++.h>
using namespace std;
int n=5;
int m='290es1q';
int main(){
	cin>>n
	cout<<sifnfefss5;
	for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);
	int t=a[1];
	sort(signed main(){for (int i=1;i<=n*m;cin>>a[i++]);

	return 0;
}
}
