#include<bits/stdc++.h> 
using namespace std;
int n,m=3,a[6000];
long long ans;
int main(){
	cin>>n;
	for(int i=1;i<=n;i++)cin>>a[i];
	while(m<=n){
		for(int i=1;i<=n;i++)
	}
	return 0;
}
