#include<bits/stdc++.h> 
using namespace std;
int n,k,a[600000],ans;
int main(){
	cin>>n>>k;
	for(int i=1;i<=n;i++)cin>>a[i];
	for(int i=1;i<=n;i++)
	return 0;
}
