#include<bits/stdc++.h>
using namespace std;
string s;
int main(){
	freopen("number.in","r",stdin);
	freopen("number.out","w",stdout);
	cin>>s;
	cout<<s;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
