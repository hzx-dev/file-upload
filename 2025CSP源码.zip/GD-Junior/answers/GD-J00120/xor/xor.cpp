#include<bits/stdc++.h>
using namespace std;
long long n,k;
long long a[100010];
int main(){
	freopen("xor.in","r",stdin);
	freopen("xor.out","w",stdout);
	cin>>n>>k;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	cout<<"1";
	fclose(stdin);
	fclose(stdout);
	return 0;
}
/*
4 0
2 1 0 3
1
*/
