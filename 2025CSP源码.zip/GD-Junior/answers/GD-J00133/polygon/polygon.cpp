#include<bits/stdc++.h>
using namespace std;
const int mod=998244353;
int n,a[5005],ans=1;
int main(){
	freopen("polygon.in","r",stdin);
	freopen("polygon.out","w",stdout);
	cin>>n;for(int i=0;i<n;i++){
		cin>>a[i];
	}printf("%d",ans);
	return 0;
	fclose(stdin);
	fclose(stdout);
}
